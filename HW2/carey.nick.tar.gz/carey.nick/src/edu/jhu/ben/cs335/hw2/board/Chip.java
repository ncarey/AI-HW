package edu.jhu.ben.cs335.hw2.board;

/**
 * An enum to represent possible tile occupancy
 *
 * @author Ben Mitchell
 */
public enum Chip { BLACK, WHITE, NONE }

