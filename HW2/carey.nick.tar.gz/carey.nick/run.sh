#!/bin/bash

JAVA_ARGS="$@" make run -C src
