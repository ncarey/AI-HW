#!/bin/bash

make ARGS="../data/map1.txt BFS" run -C src
