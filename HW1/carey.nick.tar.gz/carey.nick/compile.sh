#!/bin/bash

make -C src
